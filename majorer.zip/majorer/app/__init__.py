"""
App module init
"""
